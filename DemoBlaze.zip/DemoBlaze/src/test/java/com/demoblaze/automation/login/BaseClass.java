package com.demoblaze.automation.login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.annotations.*;

import java.time.Duration;

public class BaseClass {
    protected WebDriver driver;


    @Parameters({"Browser"})
    @BeforeMethod(alwaysRun = true)
    public void startBrowser(@Optional("chrome") String browser){
        switch (browser) {
            case "chrome":

                driver = new ChromeDriver();
                break;

            case "firefox":
                driver = new FirefoxDriver();
                break;

            case "edge":
                driver = new EdgeDriver();
                break;
        }

        driver.manage().window().maximize();
        driver.get("https://www.demoblaze.com/");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        System.out.println("Browser started");
    }

    @AfterMethod(alwaysRun = true)
    public void closeBrowser(){
        driver.quit();
        System.out.println("Browser closed");
    }

    protected void waitForSomeTime(){
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

/// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//              Only for testing purpose
@Test
public void tester(){
    System.out.println("This is normal test method..");
}
    @BeforeClass
    public void beforeClass(){
        System.out.println("This is before class");
    }
    @AfterClass
    public void afterClass(){
        System.out.println("This is after class");
    }
    @BeforeTest
    public void beforeTest(){
        System.out.println("This is before Test");
    }
    @AfterTest
    public void afterTest() {
        System.out.println("This is after Test");
    }
    @BeforeSuite
    public void beforeMethod(){
        System.out.println("This is Before suite.");
    }
    @AfterSuite
    public void aftermethod(){
        System.out.println("This is After suite.");
    }

}
